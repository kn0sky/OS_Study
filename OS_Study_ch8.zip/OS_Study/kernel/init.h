void init_all(void);
