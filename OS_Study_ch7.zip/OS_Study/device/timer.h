void timer_init();

