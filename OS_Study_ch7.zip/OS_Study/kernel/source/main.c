#include "print.h"
#include "init.h"
void main(void){
	put_str("\nI am kernel\n");
	init_all();
	asm volatile("sti");	//开启中断
	while(1);
}
