typedef void* intr_handler;
void idt_init();
