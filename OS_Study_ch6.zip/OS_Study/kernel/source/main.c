#include "print.h"
int main(){
	put_str("\nhello kernel\n");
	put_int(0);
	put_char('\n');
	put_int(0x00001500);
	put_char('\n');
	put_int(0x11112345);
	put_char('\n');
	put_int(9);
	put_char('\n');
	put_int(0x0);
	put_char('\n');
	while(1);
	return 0;
}
