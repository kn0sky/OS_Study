#include "stdio.h"
int main(){
    printf("prog_no_arg from disk\n");
    while(1);
    return 0;
}